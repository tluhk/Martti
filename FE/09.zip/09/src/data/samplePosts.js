// samplePosts.js
export const posts = [
  {
    id: 1,
    title: 'First Blog Post',
    content: 'This is the content of the first blog post.',
    author: 'John Doe',
    date: '2024-05-22',
  },
  {
    id: 2,
    title: 'Second Blog Post',
    content: 'This is the content of the second blog post.',
    author: 'Jane Smith',
    date: '2024-05-23',
  },
  {
    id: 3,
    title: 'Third Blog Post',
    content: 'This is the content of the third blog post.',
    author: 'Mike Brown',
    date: '2024-05-24',
  },
];
