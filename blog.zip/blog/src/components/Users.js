import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

function Users() {
  return (
  <Container>
    <Row>
      <Col>
        <h1 className="display-4">Users</h1>
      </Col>
    </Row>
  </Container>
  );
};

export default Users;
